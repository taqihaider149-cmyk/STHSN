import os, sqlite3
from datetime import datetime
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash, send_from_directory, Response
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

BASE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(BASE, "sthsn.db")
UPLOADS = os.path.join(BASE, "uploads")
os.makedirs(UPLOADS, exist_ok=True)

app = Flask(__name__)
app.secret_key = os.environ.get("STHSN_SECRET", "change-this-secret-key")
app.config["MAX_CONTENT_LENGTH"] = 100 * 1024 * 1024
ALLOWED_IMAGE = {"png","jpg","jpeg","gif","webp"}
ALLOWED_VIDEO = {"mp4","webm","mov","m4v","ogv"}

def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    c = db()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS users(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      username TEXT UNIQUE NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      bio TEXT DEFAULT '',
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS posts(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      text TEXT DEFAULT '',
      image TEXT DEFAULT '',
      video TEXT DEFAULT '',
      created_at TEXT NOT NULL,
      FOREIGN KEY(user_id) REFERENCES users(id)
    );
    CREATE TABLE IF NOT EXISTS likes(
      user_id INTEGER NOT NULL,
      post_id INTEGER NOT NULL,
      PRIMARY KEY(user_id, post_id)
    );
    CREATE TABLE IF NOT EXISTS comments(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      post_id INTEGER NOT NULL,
      text TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS follows(
      follower_id INTEGER NOT NULL,
      following_id INTEGER NOT NULL,
      PRIMARY KEY(follower_id, following_id)
    );
    CREATE TABLE IF NOT EXISTS messages(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sender_id INTEGER NOT NULL,
      receiver_id INTEGER NOT NULL,
      text TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS notifications(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      actor_id INTEGER NOT NULL,
      kind TEXT NOT NULL,
      post_id INTEGER DEFAULT NULL,
      created_at TEXT NOT NULL,
      is_read INTEGER DEFAULT 0
    );
    """)
    # Safe migration for databases created by older STHSN versions.
    cols = {r[1] for r in c.execute("PRAGMA table_info(posts)").fetchall()}
    if "video" not in cols:
        c.execute("ALTER TABLE posts ADD COLUMN video TEXT DEFAULT ''")
    c.commit()
    c.close()

def current_user():
    uid = session.get("user_id")
    if not uid: return None
    c=db(); u=c.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone(); c.close()
    return u

def login_required(f):
    @wraps(f)
    def w(*a, **kw):
        if not current_user():
            return redirect(url_for("login", next=request.path))
        return f(*a, **kw)
    return w

def notify(user_id, actor_id, kind, post_id=None):
    if user_id == actor_id: return
    c=db()
    c.execute("INSERT INTO notifications(user_id,actor_id,kind,post_id,created_at) VALUES(?,?,?,?,?)",
              (user_id,actor_id,kind,post_id,datetime.utcnow().isoformat()))
    c.commit(); c.close()

def nice(dt):
    return dt.replace("T"," ")[:16]

@app.route("/manifest.json")
def manifest():
    return send_from_directory(os.path.join(BASE, "static"), "manifest.json", mimetype="application/manifest+json")

@app.route("/service-worker.js")
def service_worker():
    return send_from_directory(os.path.join(BASE, "static"), "sw.js", mimetype="application/javascript")

@app.route("/robots.txt")
def robots():
    return Response("User-agent: *\nAllow: /\nDisallow: /home\nDisallow: /messages\nDisallow: /notifications\nDisallow: /users\nDisallow: /logout\nSitemap: " + request.url_root.rstrip("/") + "/sitemap.xml\n", mimetype="text/plain")

@app.route("/sitemap.xml")
def sitemap():
    base=request.url_root.rstrip("/")
    urls=[base+"/", base+"/login", base+"/register", base+"/privacy", base+"/terms"]
    xml=['<?xml version="1.0" encoding="UTF-8"?>','<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">']
    for u in urls: xml.append(f"<url><loc>{u}</loc></url>")
    xml.append('</urlset>')
    return Response(''.join(xml),mimetype='application/xml')

@app.route("/privacy")
def privacy():
    return render_template("privacy.html")

@app.route("/terms")
def terms():
    return render_template("terms.html")

@app.context_processor
def inject():
    return {"me": current_user(), "nice": nice}

@app.route("/")
def landing():
    if current_user():
        return redirect(url_for("home"))
    return render_template("landing.html")

@app.route("/home")
@login_required
def home():
    c=db()
    posts=c.execute("""
      SELECT p.*, u.name, u.username,
      (SELECT COUNT(*) FROM likes l WHERE l.post_id=p.id) likes,
      (SELECT COUNT(*) FROM comments cm WHERE cm.post_id=p.id) comments,
      EXISTS(SELECT 1 FROM likes l WHERE l.post_id=p.id AND l.user_id=?) liked
      FROM posts p JOIN users u ON u.id=p.user_id
      ORDER BY p.id DESC LIMIT 50
    """,(session["user_id"],)).fetchall()
    comments = {}
    for p in posts:
        comments[p["id"]] = c.execute("""SELECT cm.*,u.name,u.username FROM comments cm JOIN users u ON u.id=cm.user_id WHERE cm.post_id=? ORDER BY cm.id DESC LIMIT 20""", (p["id"],)).fetchall()
    c.close()
    return render_template("home.html", posts=posts, comments=comments)

@app.route("/register", methods=["GET","POST"])
def register():
    if request.method=="POST":
        name=request.form["name"].strip()
        username=request.form["username"].strip().lower().lstrip("@")
        email=request.form["email"].strip().lower()
        password=request.form["password"]
        if not all([name,username,email,password]):
            flash("All fields are required."); return render_template("auth.html", mode="register")
        c=db()
        try:
            cur=c.execute("INSERT INTO users(name,username,email,password,created_at) VALUES(?,?,?,?,?)",
              (name,username,email,generate_password_hash(password),datetime.utcnow().isoformat()))
            c.commit(); uid=cur.lastrowid
        except sqlite3.IntegrityError:
            c.close(); flash("Username or email already exists."); return render_template("auth.html", mode="register")
        c.close(); session["user_id"]=uid
        return redirect(url_for("home"))
    return render_template("auth.html", mode="register")

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method=="POST":
        key=request.form["key"].strip().lower()
        password=request.form["password"]
        c=db(); u=c.execute("SELECT * FROM users WHERE email=? OR username=?", (key,key.lstrip("@"))).fetchone(); c.close()
        if u and check_password_hash(u["password"],password):
            session["user_id"]=u["id"]; return redirect(request.args.get("next") or url_for("home"))
        flash("Invalid login details.")
    return render_template("auth.html", mode="login")

@app.route("/logout")
def logout():
    session.clear(); return redirect(url_for("login"))

@app.route("/post", methods=["POST"])
@login_required
def create_post():
    text=request.form.get("text","").strip()
    image=""
    video=""
    f=request.files.get("image")
    v=request.files.get("video")
    if f and f.filename:
        ext=f.filename.rsplit(".",1)[-1].lower()
        if ext not in ALLOWED_IMAGE:
            flash("This image type is not allowed."); return redirect(url_for("home"))
        filename=f"{datetime.utcnow().strftime('%Y%m%d%H%M%S%f')}_{secure_filename(f.filename)}"
        f.save(os.path.join(UPLOADS,filename)); image=filename
    if v and v.filename:
        ext=v.filename.rsplit(".",1)[-1].lower()
        if ext not in ALLOWED_VIDEO:
            flash("This video type is not allowed."); return redirect(url_for("home"))
        filename=f"{datetime.utcnow().strftime('%Y%m%d%H%M%S%f')}_{secure_filename(v.filename)}"
        v.save(os.path.join(UPLOADS,filename)); video=filename
    if not text and not image and not video:
        flash("Write something or choose a photo/video."); return redirect(url_for("home"))
    if image and video:
        flash("Please choose either a photo or a video, not both."); return redirect(url_for("home"))
    c=db(); c.execute("INSERT INTO posts(user_id,text,image,video,created_at) VALUES(?,?,?,?,?)",
                      (session["user_id"],text,image,video,datetime.utcnow().isoformat())); c.commit(); c.close()
    return redirect(url_for("home"))

@app.route("/like/<int:post_id>", methods=["POST"])
@login_required
def like(post_id):
    c=db()
    exists=c.execute("SELECT 1 FROM likes WHERE user_id=? AND post_id=?",(session["user_id"],post_id)).fetchone()
    p=c.execute("SELECT user_id FROM posts WHERE id=?",(post_id,)).fetchone()
    if exists:
        c.execute("DELETE FROM likes WHERE user_id=? AND post_id=?",(session["user_id"],post_id)); liked=False
    else:
        c.execute("INSERT INTO likes(user_id,post_id) VALUES(?,?)",(session["user_id"],post_id)); liked=True
        if p: notify(p["user_id"],session["user_id"],"liked",post_id)
    c.commit(); count=c.execute("SELECT COUNT(*) n FROM likes WHERE post_id=?",(post_id,)).fetchone()["n"]; c.close()
    return jsonify(liked=liked,count=count)

@app.route("/comment/<int:post_id>", methods=["POST"])
@login_required
def comment(post_id):
    text=request.form.get("text","").strip()
    if text:
        c=db(); p=c.execute("SELECT user_id FROM posts WHERE id=?",(post_id,)).fetchone()
        c.execute("INSERT INTO comments(user_id,post_id,text,created_at) VALUES(?,?,?,?)",
                  (session["user_id"],post_id,text,datetime.utcnow().isoformat()))
        c.commit(); c.close()
        if p: notify(p["user_id"],session["user_id"],"commented",post_id)
    return redirect(url_for("home"))

@app.route("/profile/<username>")
@login_required
def profile(username):
    c=db(); u=c.execute("SELECT * FROM users WHERE username=?",(username.lower().lstrip("@"),)).fetchone()
    if not u: c.close(); return "User not found",404
    posts=c.execute("SELECT * FROM posts WHERE user_id=? ORDER BY id DESC",(u["id"],)).fetchall()
    followers=c.execute("SELECT COUNT(*) n FROM follows WHERE following_id=?",(u["id"],)).fetchone()["n"]
    following=c.execute("SELECT COUNT(*) n FROM follows WHERE follower_id=?",(u["id"],)).fetchone()["n"]
    is_following=c.execute("SELECT 1 FROM follows WHERE follower_id=? AND following_id=?",(session["user_id"],u["id"])).fetchone()
    c.close()
    return render_template("profile.html",user=u,posts=posts,followers=followers,following=following,is_following=bool(is_following))

@app.route("/follow/<int:user_id>", methods=["POST"])
@login_required
def follow(user_id):
    if user_id==session["user_id"]: return jsonify(ok=False)
    c=db(); ex=c.execute("SELECT 1 FROM follows WHERE follower_id=? AND following_id=?",(session["user_id"],user_id)).fetchone()
    if ex:
        c.execute("DELETE FROM follows WHERE follower_id=? AND following_id=?",(session["user_id"],user_id)); following=False
    else:
        c.execute("INSERT INTO follows(follower_id,following_id) VALUES(?,?)",(session["user_id"],user_id)); following=True
        notify(user_id,session["user_id"],"followed")
    c.commit(); c.close(); return jsonify(following=following)

@app.route("/notifications")
@login_required
def notifications():
    c=db(); rows=c.execute("""
      SELECT n.*,u.name,u.username FROM notifications n JOIN users u ON u.id=n.actor_id
      WHERE n.user_id=? ORDER BY n.id DESC LIMIT 50
    """,(session["user_id"],)).fetchall()
    c.execute("UPDATE notifications SET is_read=1 WHERE user_id=?",(session["user_id"],)); c.commit(); c.close()
    return render_template("notifications.html",rows=rows)

@app.route("/messages/<username>", methods=["GET","POST"])
@login_required
def messages(username):
    c=db(); other=c.execute("SELECT * FROM users WHERE username=?",(username.lower().lstrip("@"),)).fetchone()
    if not other: c.close(); return "User not found",404
    if request.method=="POST":
        text=request.form.get("text","").strip()
        if text: c.execute("INSERT INTO messages(sender_id,receiver_id,text,created_at) VALUES(?,?,?,?)",
                            (session["user_id"],other["id"],text,datetime.utcnow().isoformat()))
        c.commit()
    rows=c.execute("""SELECT m.*,u.username FROM messages m JOIN users u ON u.id=m.sender_id
      WHERE (sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?)
      ORDER BY m.id""",(session["user_id"],other["id"],other["id"],session["user_id"])).fetchall()
    c.close(); return render_template("messages.html",other=other,rows=rows)

@app.route("/users")
@login_required
def users():
    q=request.args.get("q","").strip().lower()
    c=db(); rows=c.execute("SELECT id,name,username,bio FROM users WHERE username LIKE ? OR name LIKE ? LIMIT 30",
                           (f"%{q}%",f"%{q}%")).fetchall(); c.close()
    return render_template("users.html",rows=rows,q=q)

@app.route("/seed")
def seed():
    # Convenient demo data: only runs if database has no users.
    c=db()
    if c.execute("SELECT COUNT(*) n FROM users").fetchone()["n"]==0:
        pw=generate_password_hash("STHSN123")
        c.execute("INSERT INTO users(name,username,email,password,created_at) VALUES(?,?,?,?,?)",
                  ("Syed Taqi Haider","syedtaqihaider","taqi@sthsn.local",pw,datetime.utcnow().isoformat()))
        c.execute("INSERT INTO users(name,username,email,password,created_at) VALUES(?,?,?,?,?)",
                  ("STHSN Team","sthsn","team@sthsn.local",pw,datetime.utcnow().isoformat()))
        c.commit()
    c.close()
    return redirect(url_for("login"))

@app.route('/uploads/<filename>')
def uploaded(filename):
    from flask import send_from_directory
    return send_from_directory(UPLOADS, filename)

if __name__=="__main__":
    init_db()
    app.run(host="0.0.0.0",port=int(os.environ.get("PORT",5000)),debug=False)
