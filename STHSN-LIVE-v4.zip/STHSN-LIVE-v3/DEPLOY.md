# STHSN — LIVE DEPLOYMENT

## What is ready
This package contains:
- STHSN / Syed Taqi Haider logo
- Flask backend
- accounts and password hashing
- posts, image uploads, likes, comments
- profiles, follow/unfollow
- notifications
- direct messages
- search
- Gunicorn production server config
- Render deployment blueprint

## Important
I cannot create the public hosting account or enter your private account credentials from this chat.
To put STHSN on the internet, you need to create/connect a hosting account and authorize the deployment.

## Easiest deployment route
1. Create a GitHub account if you do not already have one.
2. Create a new GitHub repository named `sthsn`.
3. Upload all files from this package to that repository.
4. Create a Render account and connect GitHub.
5. Create a new Blueprint/Infrastructure deployment from the repository.
6. Render will read `render.yaml`, create the web service and PostgreSQL database.
7. After deployment, Render gives you a public `onrender.com` address.
8. Test registration, login, posting, comments, follows and messages.

## Before public launch
- Set a strong secret key (the Render blueprint generates one).
- Add email verification and password reset.
- Add rate limiting and moderation/reporting.
- Move image uploads to durable object storage (the current upload folder is suitable for development, not long-term production storage).
- Add backups and monitoring.
- Use a custom domain such as `sthsn.com` if you own one.

## Local test
Install Python 3.11+:
    python -m venv .venv
    pip install -r requirements.txt
    python app.py

Then open:
    http://127.0.0.1:5000
