# STHSN — Real Backend Version

STHSN is a social-media website branded with the STHSN / Syed Taqi Haider logo.

## Included
- Real Flask backend
- SQLite database
- Account registration and login
- Password hashing
- Posts
- Image uploads
- Likes
- Comments
- Profiles
- Follow / unfollow
- Notifications
- Direct messages
- User search
- Responsive mobile UI
- STHSN logo included in `static/sthsn-logo.png`

## Run on a computer
1. Install Python 3.11+.
2. Open a terminal in this folder.
3. Run: `python -m venv .venv`
4. Activate the virtual environment.
5. Run: `pip install -r requirements.txt`
6. Run: `python app.py`
7. Open `http://127.0.0.1:5000`

## Demo setup
Open `/seed` once. It creates demo accounts if the database is empty.
Demo password: `STHSN123`
Demo users:
- `syedtaqihaider`
- `sthsn`

Change the secret key and demo passwords before production.

## Important production step
For a public website, deploy this project on a server and use a production database
(PostgreSQL is recommended). Uploaded files should use durable object storage.
HTTPS, rate limiting, email verification, password reset, moderation and backups
should also be configured before public launch.
