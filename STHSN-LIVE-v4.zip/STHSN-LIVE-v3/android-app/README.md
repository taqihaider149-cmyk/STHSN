# STHSN Android / Google Play

This folder documents the Android packaging step. The web app should first be deployed on a permanent HTTPS domain, for example `https://sthsn.example`.

## Recommended route: PWA + Trusted Web Activity (Bubblewrap)

1. Deploy STHSN and confirm `https://YOUR-DOMAIN/static/manifest.json` works.
2. Install Node.js and Bubblewrap on a development computer.
3. Run:
   `npm i -g @bubblewrap/cli`
4. Initialize the Android project:
   `bubblewrap init --manifest=https://YOUR-DOMAIN/static/manifest.json`
5. Use the package name `com.sthsn.social` (change only before publishing if you want a different permanent package name).
6. Build and test the Android app with Bubblewrap/Android Studio.
7. Configure Digital Asset Links at `https://YOUR-DOMAIN/.well-known/assetlinks.json` using the signing certificate fingerprint.
8. Build the release Android App Bundle (AAB) and upload it to Google Play Console.

The final Play Store submission also needs store listing details, screenshots, privacy policy, data-safety information, content declarations and review access where required.

## Important for STHSN

Because STHSN is a social network with user-generated photos/videos, add a production moderation/reporting system, account deletion flow, abuse handling, secure media storage, rate limiting, HTTPS, backups and a complete privacy policy before public release.
